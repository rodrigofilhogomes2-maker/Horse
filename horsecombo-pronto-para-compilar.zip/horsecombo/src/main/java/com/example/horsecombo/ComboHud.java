package com.example.horsecombo;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public final class ComboHud {
    public static final Counter DEALT = new Counter(false);
    public static final Counter TAKEN = new Counter(true);

    private static final long COMBO_TIMEOUT_MS = 3000;
    private static final long FADE_MS = 400;
    private static final long FLOAT_LIFE_MS = 1000;
    private static final Random RNG = new Random();

    private ComboHud() {}

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();
        long now = System.currentTimeMillis();
        TextRenderer tr = mc.textRenderer;
        DEALT.render(ctx, tr, w - 90, h / 3, w / 2 + 26, h / 2 - 12, now);
        TAKEN.render(ctx, tr, 90, h / 3, w / 2 - 26, h / 2 + 4, now);
    }

    // ---------- helpers ----------
    static String fmt(float v) {
        return v >= 10f ? String.valueOf(Math.round(v)) : String.format(Locale.ROOT, "%.1f", v);
    }

    static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }

    static int lerpColor(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private static final int[] STOPS_T = {0, 10, 30, 60, 100};
    private static final int[] STOPS_C = {0xFFFFFF, 0xFFE14D, 0xFF9A2E, 0xFF4040, 0xFF3DD8};

    static int comboColor(float total, boolean taken) {
        if (taken) return lerpColor(0xFF8A8A, 0xFF1F1F, clamp01(total / 40f));
        for (int i = 0; i < STOPS_T.length - 1; i++) {
            if (total < STOPS_T[i + 1]) {
                return lerpColor(STOPS_C[i], STOPS_C[i + 1],
                        (total - STOPS_T[i]) / (float) (STOPS_T[i + 1] - STOPS_T[i]));
            }
        }
        return STOPS_C[STOPS_C.length - 1];
    }

    static void drawText(DrawContext ctx, TextRenderer tr, String s, float cx, float cy,
                         float scale, int rgb, float alpha) {
        int a = (int) (clamp01(alpha) * 255);
        if (a < 8) return;
        int color = (a << 24) | (rgb & 0xFFFFFF);
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(cx, cy, 0);
        m.scale(scale, scale, 1f);
        ctx.drawText(tr, s, -tr.getWidth(s) / 2, -tr.fontHeight / 2, color, true);
        m.pop();
    }

    // ---------- contador ----------
    private static final class Floater {
        final String text; final long start; final float dx, dy, scale; final int color;
        Floater(String text, long start, float dx, float dy, float scale, int color) {
            this.text = text; this.start = start; this.dx = dx; this.dy = dy;
            this.scale = scale; this.color = color;
        }
    }

    public static final class Counter {
        private final boolean taken;
        private final List<Floater> floaters = new ArrayList<>();
        private float total;
        private int hits;
        private long lastHitMs;

        Counter(boolean taken) { this.taken = taken; }

        public void add(float dmg) {
            long now = System.currentTimeMillis();
            if (hits == 0 || now - lastHitMs > COMBO_TIMEOUT_MS) { total = 0; hits = 0; }
            total += dmg;
            hits++;
            lastHitMs = now;

            float size = 1.0f + clamp01(dmg / 20f) * 0.9f;
            int color = taken ? 0xFF4A4A : lerpColor(0xFFFFFF, 0xFFB52E, clamp01(dmg / 12f));
            floaters.add(new Floater((taken ? "-" : "") + fmt(dmg), now,
                    (RNG.nextFloat() - 0.5f) * 26f, (RNG.nextFloat() - 0.5f) * 14f, size, color));
        }

        void render(DrawContext ctx, TextRenderer tr, int px, int py, int fx, int fy, long now) {
            // Números flutuantes: sobem, "estouram" no começo e somem
            Iterator<Floater> it = floaters.iterator();
            while (it.hasNext()) {
                Floater f = it.next();
                long age = now - f.start;
                if (age > FLOAT_LIFE_MS) { it.remove(); continue; }
                float t = age / (float) FLOAT_LIFE_MS;
                float rise = 1f - (1f - t) * (1f - t);
                float pop = age < 150 ? 1f + 0.7f * (1f - age / 150f) : 1f;
                float alpha = t < 0.55f ? 1f : 1f - (t - 0.55f) / 0.45f;
                drawText(ctx, tr, f.text, fx + f.dx, fy + f.dy - rise * 34f,
                        f.scale * pop, f.color, alpha);
            }

            // Painel do combo
            if (hits == 0) return;
            long since = now - lastHitMs;
            if (since > COMBO_TIMEOUT_MS + FADE_MS) { hits = 0; total = 0; return; }
            float alpha = since <= COMBO_TIMEOUT_MS ? 1f
                    : 1f - (since - COMBO_TIMEOUT_MS) / (float) FADE_MS;

            float p = clamp01(since / 180f);
            float pop = 1f + 0.6f * (1f - p) * (1f - p);
            float shake = (float) Math.sin(since * 0.12) * (1f - p) * 3f;
            int color = comboColor(total, taken);

            drawText(ctx, tr, fmt(total), px + shake, py, 2.6f * pop, color, alpha);
            String label = (taken ? "RECEBIDO x" : "COMBO x") + hits;
            drawText(ctx, tr, label, px, py + 22, 1.0f, 0xFFFFFF, alpha * 0.9f);

            // Barra de tempo do combo
            int barW = 70;
            float left = clamp01(1f - since / (float) COMBO_TIMEOUT_MS);
            int a = (int) (clamp01(alpha) * 255);
            if (a >= 8) {
                int x0 = px - barW / 2, y0 = py + 32;
                ctx.fill(x0 - 1, y0 - 1, x0 + barW + 1, y0 + 4, ((a * 2 / 3) << 24));
                ctx.fill(x0, y0, x0 + Math.round(barW * left), y0 + 3, (a << 24) | color);
            }
        }
    }
}
