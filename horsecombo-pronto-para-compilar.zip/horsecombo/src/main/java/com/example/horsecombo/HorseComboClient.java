package com.example.horsecombo;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.util.ActionResult;

public class HorseComboClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(DamageTracker::tick);
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> ComboHud.render(ctx));

        // Marca o alvo quando o jogador ataca (ajuda a atribuir o dano ao jogador)
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient) DamageTracker.markAttack(entity);
            return ActionResult.PASS;
        });
    }
}
