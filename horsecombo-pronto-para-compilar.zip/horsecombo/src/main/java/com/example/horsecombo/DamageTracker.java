package com.example.horsecombo;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;

import java.util.HashMap;
import java.util.Map;

/** Detecta queda de vida no cliente e alimenta os contadores de combo. */
public final class DamageTracker {
    private static final long ATTACK_WINDOW_MS = 1000;

    private static final Map<Integer, Float> lastHealth = new HashMap<>();
    private static final Map<Integer, Long> attackedAt = new HashMap<>();
    private static float lastPlayerHealth = -1f;

    private DamageTracker() {}

    public static void markAttack(Entity e) {
        attackedAt.put(e.getId(), System.currentTimeMillis());
    }

    public static void tick(MinecraftClient mc) {
        ClientWorld world = mc.world;
        ClientPlayerEntity player = mc.player;
        if (world == null || player == null) {
            lastHealth.clear();
            attackedAt.clear();
            lastPlayerHealth = -1f;
            return;
        }
        long now = System.currentTimeMillis();

        // 1) Dano causado pelo jogador em outras entidades
        Map<Integer, Float> current = new HashMap<>();
        for (Entity e : world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == player) continue;
            float hp = le.getHealth() + le.getAbsorptionAmount();
            current.put(le.getId(), hp);
            Float prev = lastHealth.get(le.getId());
            if (prev != null && hp < prev - 0.01f && causedByPlayer(le, player, now)) {
                ComboHud.DEALT.add(prev - hp);
            }
        }
        lastHealth.clear();
        lastHealth.putAll(current);
        attackedAt.values().removeIf(t -> now - t > 5000);

        // 2) Dano recebido pelo jogador vindo de entidades
        float php = player.getHealth() + player.getAbsorptionAmount();
        if (lastPlayerHealth >= 0f && php < lastPlayerHealth - 0.01f) {
            DamageSource src = player.getRecentDamageSource();
            Entity attacker = src != null ? src.getAttacker() : null;
            if (attacker != null && attacker != player) {
                ComboHud.TAKEN.add(lastPlayerHealth - php);
            }
        }
        lastPlayerHealth = php;
    }

    private static boolean causedByPlayer(LivingEntity target, ClientPlayerEntity player, long now) {
        DamageSource src = target.getRecentDamageSource();
        if (src != null && (src.getAttacker() == player || src.getSource() == player)) return true;
        Long t = attackedAt.get(target.getId());
        return t != null && now - t <= ATTACK_WINDOW_MS;
    }
}
