package com.example.horsecombo.mixin;

import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    /**
     * A força do pulo do cavalo é calculada pelo tempo que você segura o botão.
     * Aqui ela sempre vale 1.0 (máximo), então um único clique já dá o pulo máximo.
     */
    @Inject(method = "getMountJumpStrength", at = @At("HEAD"), cancellable = true)
    private void horsecombo$maxJump(CallbackInfoReturnable<Float> cir) {
        cir.setReturnValue(1.0F);
    }
}
